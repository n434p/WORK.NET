﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    class Subject : ISubject
    {
        List<IObserver> observers = new List<IObserver>();

        private decimal usdRate;
        public decimal UsdRate
        {
            set
            {
                if (value > 0) { usdRate = value; } else { usdRate = 0; }
            }

            get
            {
                return usdRate;
            }
        }



        public void Attach(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Detach(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void Notify()
        {
            foreach (IObserver obs in observers)
            {
                obs.Update(this);
            }
        }
    }
}
