﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    abstract class IObserver
    {
        internal decimal usdSaleRate;
        internal decimal usdBuyRate;
        internal string bankName = String.Empty;

        public abstract void Update(ISubject subj);

        public override string ToString()
        {
            return String.Format("{0}, USD: покупка {1}, продажа {2}.", bankName, Math.Round(usdBuyRate, 2), Math.Round(usdSaleRate, 2));
        }
    }
}
