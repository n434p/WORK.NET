﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    class Program
    {
        static void Main(string[] args)
        {   // Нац банк в роли субьекта, он совершает оповещение всех подписавшихся на изменеия.
            Subject natBank = new Subject();
            // Список слушателей(банков).
            List<IObserver> banks = new List<IObserver>();

            PrivatBank privat = new PrivatBank();
            banks.Add(privat);
            Aval aval = new Aval();
            banks.Add(aval);
            KreditDnepr kdn = new KreditDnepr();
            banks.Add(kdn);

            // Вывод не сформированных курсов валют
            ShowExchangeRates(banks);

            // Добавление слушателей на изменение курса валют выставляемого нац банком.
            natBank.Attach(aval);
            natBank.Attach(kdn);
            natBank.Attach(privat);

            // Установка курса валют, и оповещение всех подписавшихся (слушателей).
            natBank.UsdRate = 21.1961m;
            natBank.Notify();

            
            Console.WriteLine("\nКурс нац банка: {0}", natBank.UsdRate);
            // Просмотр курсов валют вычисленных после оповещения нац банком
            ShowExchangeRates(banks);

            // Отключение одного слушателя.
            natBank.Detach(kdn);

            // Установка курса валют, и оповещение подписавшихся (оставшихся слушателей).
            natBank.UsdRate = 10.0m;
            natBank.Notify();

            Console.WriteLine("\nКурс нац банка: {0}. !!! Кредит Днепр отключили от банковской системы.", natBank.UsdRate);
            ShowExchangeRates(banks);
        }

        public static void ShowExchangeRates(List<IObserver> banks)
        {
            foreach (IObserver bank in banks)
            {
                Console.WriteLine(bank);
            }
        }
    }
}
