﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    class PrivatBank : IObserver
    {
        public PrivatBank() {
            bankName = "Privat Bank";
        }

        public override void Update(ISubject subj)
        {
            usdBuyRate = ((Subject)subj).UsdRate * 0.948287656692m;
            usdSaleRate = ((Subject)subj).UsdRate * 1.042644637457m;
        }
    }

    class Aval : IObserver
    {
        public Aval()
        {
            bankName = "Aval";
        }

        public override void Update(ISubject subj)
        {
            usdBuyRate = ((Subject)subj).UsdRate * 1.014337543227m;
            usdSaleRate = ((Subject)subj).UsdRate * 1.06151603361m;
        }
    }

    class KreditDnepr : IObserver
    {
        public KreditDnepr()
        {
            bankName = "Kredit Dnepr";
        }

        public override void Update(ISubject subj)
        {
            usdBuyRate = ((Subject)subj).UsdRate * 1.004901845151m;
            usdSaleRate = ((Subject)subj).UsdRate * 1.042644637457m;
        }
    }

}
