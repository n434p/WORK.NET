﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using InterfaceImageProject;


namespace MainProjectImage
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, InterfaceImageProject.IMainProject
    {
        Dictionary<string, IPlugin> plugins = new Dictionary<string, IPlugin>();

        public MainWindow()
        {
            InitializeComponent();
            FindPlugins();

        }

        public BitmapImage MyImage
        {
            get
            {
                return (BitmapImage)myImage.Source;
            }
            set
            {
                myImage.Source = value;
            }

        }

        void FindPlugins()
        {
            string myFolder = System.AppDomain.CurrentDomain.BaseDirectory;
            //MessageBox.Show(myFolder);
            string[] files = Directory.GetFiles(myFolder, "*.dll");
            foreach (string f in files)
            {
                try
                {
                    Assembly asm = Assembly.LoadFile(f);
                    foreach (Type t in asm.GetTypes())
                    {
                        Type iType = t.GetInterface("InterfaceImageProject.IPlugin");
                        if (iType != null)
                        {
                            IPlugin plugin = (IPlugin)Activator.CreateInstance(t);
                            plugins.Add(plugin.Name, plugin);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки плагина\n" + ex.Message);
                }
            }
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            FindPlugins();
            MessageBox.Show(plugins.Count.ToString());
            foreach (string str in plugins.Keys)
            {
                lbNamePlugin.Items.Add(str);            
            }
        }
    }
}
